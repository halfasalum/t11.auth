# t11.auth
 TerminalXI authentication api
