<?php

namespace App\Http\Controllers;

use App\Models\role_permissions;
use App\Models\User;
use App\Models\users_roles;
use Illuminate\Validation\ValidationException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Tymon\JWTAuth\Facades\JWTAuth;
use Exception;

class Authcontroller extends Controller
{
    public function login(Request $request)
    {
        $username = $request->username;
        $password = $request->password;
        $controls = [];
        $user = User::where('name', $username)->first();
        if ($user && Hash::check($password, $user->password)) {
            // Generate a JWT token for the authenticated user
            $roles = users_roles::where(['user_id' => $user->id, 'user_role_status' => 1])
                ->select('role_id')
                ->get();
            if (sizeof($roles) > 0) {
                foreach ($roles as $role) {
                    $role_permissions = role_permissions::where(['role_id' => $role->role_id, 'permission_status' => 1])
                        ->select('permission_id')
                        ->get();
                    if (sizeof($role_permissions) > 0) {
                        foreach ($role_permissions as $permission) {
                            $controls[] = $permission->permission_id;
                        }
                    }
                }
            }
            //$token = JWTAuth::fromUser($user, ['controls' => $controls]);
            $token = JWTAuth::claims(['controls' => $controls,'school' => $user->user_school])->fromUser($user);
            return response()->json([
                'token'     => $token,
                'name'  => $user->last_name . ", " . $user->first_name,
                'school' => $user->user_school,
                'success'   => true,
                'permissions' => $controls
            ]);
        } else {
            return response()->json([
                'token' => null,
                'username' => $username,
                'success' => false,
                'message' => 'Invalid credentials',
            ]);
        }
    }

    public function default_admin()
    {

        $user = User::where('name', 'admin')->first();
        if (!$user) {
            // Create the default admin user
            $admin = new User();
            $admin->name = 'admin';
            $admin->first_name = 'admin';
            $admin->middle_name = 'admin';
            $admin->last_name = 'admin';
            $admin->user_type = 1;
            $admin->birth_date = '2000-01-01';
            $admin->password = Hash::make('admin'); // Hash the password 'admin'
            $admin->email = 'ahbabrasul@icloud.com';    // Provide a default email
            $admin->save();

            return response()->json([
                'success' => true,
                'message' => 'Default admin account created successfully.',
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Admin account already exists.',
            ]);
        }
    }

    public function logout()
    {
        try {
            // Invalidate the token
            JWTAuth::invalidate(JWTAuth::getToken());

            return response()->json([
                'success' => true,
                'message' => 'Logout successful',
            ]);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to logout, please try again. : ' . $e,
            ], 500);
        }
    }
}
