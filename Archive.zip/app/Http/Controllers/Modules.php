<?php

namespace App\Http\Controllers;

use App\Models\modules as ModelsModules;
use App\Models\modules_controls;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class Modules extends Controller
{
    public function register(Request $request)
    {

        try {
            $validated = $request->validate([
                'module_name' => 'bail|required|string|max:255',
                'module_url' => 'required|string',
                'module_status' => 'required',
            ]);

            $module = ModelsModules::create($validated);

            return response()->json([
                'status' => 'success',
                'message' => 'Module created successfully',
                'module' => $module,
            ], 201);
        } catch (ValidationException $e) {
            return response()->json([
                'status' => 'error',
                'errors' => $e->errors(),
            ], 422);
        }
    }

    public function control_register(Request $request)
    {

        try {
            $validated = $request->validate([
                'control_name' => 'bail|required|string|max:255',
                'module_id' => 'required',
                'module_control_status' => 'required',
            ]);

            $module = modules_controls::create($validated);

            return response()->json([
                'status' => 'success',
                'message' => 'Module created successfully',
                'module' => $module,
            ], 201);
        } catch (ValidationException $e) {
            return response()->json([
                'status' => 'error',
                'errors' => $e->errors(),
            ], 422);
        }
    }

    public function listModules()
    {
        $modules = ModelsModules::where('module_status', 1)
            ->select('module_name', 'module_url')
            ->get();
        return response()->json([
            'modules' => $modules
        ]);
    }

    public function getModules()
    {
        $modules = ModelsModules::where('module_status', 1)
            ->select('id', 'module_name', 'module_url', 'created_at')
            ->get();
        return response()->json(
            $modules
        );
    }
    public function getControls($module_id = null)
    {
        $modules = modules_controls::where(['module_id' => $module_id, 'module_control_status' => 1])
            ->select('id', 'control_name', 'created_at')
            ->get();
        return response()->json(
            $modules
        );
    }
    public function getModulesControls()
    {
        $modulesWithControls = [];
        $modules = ModelsModules::where('module_status', 1)
            ->select('id', 'module_name')
            ->get();
        if (sizeof($modules) > 0) {
            foreach ($modules as $module) {
                $moduleControls = modules_controls::where(['module_id' => $module->id, 'module_control_status' => 1])
                    ->select('id', 'control_name')
                    ->get();
                $modulesWithControls[] = [
                    'module_name' => $module->module_name,
                    'controls' => $moduleControls
                ];
            }
        }
        return response()->json(
            $modulesWithControls
        );
    }
}
