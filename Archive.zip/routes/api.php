<?php

use App\Http\Controllers\Authcontroller;
use App\Http\Controllers\Modules;
use App\Http\Controllers\Roles;
use App\Http\Controllers\SystemUsers;
use App\Http\Controllers\TestController;
use App\Http\Middleware\ControlAccessMiddleware;
use App\Http\Middleware\JwtMiddleware;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/* Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum'); */

Route::post("/authenticate",[Authcontroller::class,"login"]);
Route::get("/admin",[Authcontroller::class,"default_admin"]);
Route::post("/logout",[Authcontroller::class,"logout"]);

Route::get('/send-message', [TestController::class, 'sendMessage']);


Route::get("/user/roles/{id}", [SystemUsers::class, "getRolePermissons"]);


Route::middleware([JwtMiddleware::class])->group(function () {
    Route::post("/module/register", [Modules::class, "register"])->middleware([ControlAccessMiddleware::class . ':2']);
    Route::post("/module-control/register", [Modules::class, "control_register"])->middleware([ControlAccessMiddleware::class . ':11']);
    Route::get("/module/list", [Modules::class, "listModules"])->middleware([ControlAccessMiddleware::class . ':1']);
    Route::get("/module-controls/{id}", [Modules::class, "getControls"])->middleware([ControlAccessMiddleware::class . ':1']);
    Route::get("/module/get", [Modules::class, "getModules"])->middleware([ControlAccessMiddleware::class . ':1']);
    Route::get("/modulesControls", [Modules::class, "getModulesControls"])->middleware([ControlAccessMiddleware::class . ':1']);
    Route::get("/roles/list", [Roles::class, "listRoles"])->middleware([ControlAccessMiddleware::class . ':7']);
    Route::post("/roles/register", [Roles::class, "register"])->middleware([ControlAccessMiddleware::class . ':1']);
    Route::post("/roles/registerRolePermissions", [Roles::class, "registerRolePermissions"])->middleware([ControlAccessMiddleware::class . ':1']);
    Route::get("/role-permissions/{id}", [Roles::class, "getRolePermissons"])->middleware([ControlAccessMiddleware::class . ':1']);
    Route::get('/users/list', [SystemUsers::class, 'listUsers'])->middleware([ControlAccessMiddleware::class . ':1']);
    Route::get("/roles/user/{id}", [Roles::class, "getUserAssignedRoles"])->middleware([ControlAccessMiddleware::class . ':1']);
    Route::post("/users/registerUserRoles", [SystemUsers::class, "registerUserRoles"])->middleware([ControlAccessMiddleware::class . ':1']);
    Route::post("/users/school", [SystemUsers::class, "registerSchoolAdmin"])->middleware([ControlAccessMiddleware::class . ':1']);
});
